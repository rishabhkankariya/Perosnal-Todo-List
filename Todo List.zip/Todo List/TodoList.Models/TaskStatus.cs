namespace TodoList.Models
{
    public enum TaskStatus
    {
        Pending = 0,
        InProgress = 1,
        Done = 2
    }
}
